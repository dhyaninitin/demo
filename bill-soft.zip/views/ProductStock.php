<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header brdcum">
      <h1 >
      Product Stock 
      <ol class="breadcrumb pts16 ">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Product Stock</li>
      </ol>
      </h1>
    </section>
<style type="text/css">
/*.nav-tabs-custom>.nav-tabs>li.active {
border-top-color: #3c8dbc;
border-bottom-color: #3c8dbc;
border-left-color: #3c8dbc;
border-right-color: #3c8dbc;
}
.nav-tabs-custom>.nav-tabs>li {
    border-top: 3px solid transparent;
    border-right: 3px solid transparent;
    border-left: 3px solid transparent;
    margin-right: 5px;
}*/

</style>
 
    <section class="content">
 
      <div class="row">

        <section class="col-lg-12 connectedSortable">
        <div class="box">
            <div class="col-lg-12 col-xs-6 box-body whitee">
               <table id="example1" class="table table-bordered table-striped">
                  <thead>
                      <tr >
                      <th class="tableth">#</th>
                      <th class="tableth">Category</th>
                      <th class="tableth">Product</th>
                      <th class="tableth">Description</th>
                      <th class="tableth">HSN Code</th>
                      <th class="tableth">Total Quantity</th>
                      <th class="tableth">Sell Price</th>
                      <th class="tableth"> Profit Price</th>
                      <th class="tableth">Balance</th>
                      <th class="tableth">Profit Rs</th>
                      <th class="tableth">Tax</th>
                      <!-- <th>Action</th> -->
                      </tr>
                  </thead>
                  <tbody>
                      <?php $current_year = date("Y");  $current_month = date("m");
                       $prodct=mysqli_query($con,"SELECT *,SUM(product_quantity),SUM(purchase_quantity) FROM tapp_product GROUP BY product_name   ");
                          $cnt = 1;
                           while($pro=mysqli_fetch_assoc($prodct)) {?>
                          <tr>
                            <td class="tabletd"><?php echo $cnt;?></td>
                            <td class="tabletd"><?php 
                              $cat=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tapp_pro_category WHERE id ='".$pro['category_id']."' ")); 
                              echo $cat['categoryname'];?>
                            </td>
                            <td class="tabletd text-capitalize"><?php echo $pro['product_name'];?></td>
                            <td class="tabletd"><?php echo $pro['description'];?></td>
                            <td class="tabletd"><?php echo $pro['hsn_code'];?></td>
                           
                            <td class="tabletd"><?php echo $pro['SUM(product_quantity)'].'&nbsp'. $pro['product_unit'];?></td>
                            <td class="tabletd"><?php 
                                $price=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `tapp_product` WHERE  product_name = '".$pro['product_name']."' AND YEAR(add_date) = '$current_year' AND MONTH(add_date) = '$current_month' ORDER BY add_date DESC LIMIT 1 "));  
                                echo $price['product_price'].' '.'Rs';?>
                              </td>
                               <td class="tabletd"><?php  echo $price['profit_price'].' '.'Rs';?></td>
                               <td class="tabletd"><?php  $balnce =  $pro['SUM(product_quantity)'] - $pro['SUM(purchase_quantity)']; echo $balnce.'&nbsp'. $pro['product_unit'];?></td>
                               <td class="tabletd"><?php echo $balnce * $price['profit_price'].' '.'Rs' ;?></td>
                            <td class="tabletd"><?php echo $pro['tax'] . ' %';?></td>
                           
                          </tr>
                      <?php $cnt = $cnt+1; } ?>
                  </tbody>
              </table>
            </div>  

     <!-- 
            <div class="col-lg-12 col-xs-6 box-body whitee">
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs" style="font-size: 16px;font-weight: 700;padding-bottom: 8px">
                        <li class="active"><a href="#activity" data-toggle="tab" class="normaltext">Combine Product Stock</a></li>
                        <li><a href="#timeline" data-toggle="tab" class="normaltext">Details Product Stock</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="active tab-pane" id="activity">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr >
                                    <th class="tableth">#</th>
                                    <th class="tableth">Category</th>
                                    <th class="tableth">Product</th>
                                    <th class="tableth">Description</th>
                                    <th class="tableth">HSN Code</th>
                                    <th class="tableth">Total Quantity</th>
                                    <th class="tableth">Latest Price</th>
                                    <th class="tableth"> Profit Price</th>
                                    <th class="tableth">Balance</th>
                                    <th class="tableth">Profit Rs</th>
                                    <th class="tableth">Tax</th>
                                                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $current_year = date("Y");  $current_month = date("m");
                                     $prodct=mysqli_query($con,"SELECT *,SUM(product_quantity),SUM(purchase_quantity) FROM tapp_product GROUP BY product_name   ");
                                        $cnt = 1;
                                         while($pro=mysqli_fetch_assoc($prodct)) {?>
                                        <tr>
                                          <td class="tabletd"><?php echo $cnt;?></td>
                                          <td class="tabletd"><?php 
                                            $cat=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tapp_pro_category WHERE id ='".$pro['category_id']."' ")); 
                                            echo $cat['categoryname'];?>
                                          </td>
                                          <td class="tabletd text-capitalize"><?php echo $pro['product_name'];?></td>
                                          <td class="tabletd"><?php echo $pro['description'];?></td>
                                          <td class="tabletd"><?php echo $pro['hsn_code'];?></td>
                                         
                                          <td class="tabletd"><?php echo $pro['SUM(product_quantity)'].'&nbsp'. $pro['product_unit'];?></td>
                                          <td class="tabletd"><?php 
                                              $price=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `tapp_product` WHERE  product_name = '".$pro['product_name']."' AND YEAR(add_date) = '$current_year' AND MONTH(add_date) = '$current_month' ORDER BY add_date DESC LIMIT 1 "));  
                                              echo $price['product_price'].' '.'Rs';?>
                                            </td>
                                             <td class="tabletd"><?php  echo $price['profit_price'].' '.'Rs';?></td>
                                             <td class="tabletd"><?php  $balnce =  $pro['SUM(product_quantity)'] - $pro['SUM(purchase_quantity)']; echo $balnce.'&nbsp'. $pro['product_unit'];?></td>
                                             <td class="tabletd"><?php echo $balnce * $price['profit_price'].' '.'Rs' ;?></td>
                                          <td class="tabletd"><?php echo $pro['tax'] . ' %';?></td>
                                         
                                        </tr>
                                    <?php $cnt = $cnt+1; } ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane" id="timeline">
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                     <th class="tableth">#</th>
                                     <th class="tableth">Added BY</th>
                                     <th class="tableth">Category</th>
                                     <th class="tableth">Product</th>
                                     <th class="tableth">HSN Code</th>
                                    <th class="tableth">Quantity</th>
                                     <th class="tableth">Price</th>
                                     <th class="tableth">Description</th>
                                     <th class="tableth">Tax</th>
                                     <th class="tableth">Add/Update Date</th>
                                  
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $prodct=mysqli_query($con,"SELECT * FROM tapp_product LEFT JOIN  tapp_pro_category  ON tapp_product.category_id = tapp_pro_category.id");
                                        $cnt = 1;
                                         while($pro=mysqli_fetch_assoc($prodct)) {?>
                                        <tr>
                                          <td class="tabletd"><?php echo $cnt;?></td>
                                          <td class="tabletd"><?php echo substr($pro['added_by'],0,12).'...';?></td>
                                          <td class="tabletd"><?php echo $pro['categoryname'];?></td>
                                          <td class="tabletd"><?php echo $pro['product_name'];?></td>
                                          <td class="tabletd"><?php echo $pro['hsn_code'];?></td>
                                          <td class="tabletd"><?php echo $pro['product_quantity'].'&nbsp'. $pro['product_unit'];?></td>
                                          <td class="tabletd"><?php echo $pro['product_price'];?></td>
                                          <td class="tabletd"><?php echo $pro['description'];?></td>
                                          <td class="tabletd"><?php echo $pro['tax'] . ' %';?></td>
                                          <td class="tabletd"><?php echo date("d F Y", strtotime($pro['add_date']));?></td>
                                        </tr>
                                    <?php $cnt = $cnt+1; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> -->
        </div> 

            

        </section>
      
      </div>
    

    </section>

  </div>


 
